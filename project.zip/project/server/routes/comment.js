import express from 'express';
import {Comment} from '../models.js';
const commentRouter = express.Router();

commentRouter.post('/',async(req,res)=>{
	let {post_id, writer_id, content} = req.body;
	console.log(req.body);
	const like = new Like({post_id, writer_id, content})
	await like.save();
    res.json({'status':200});
});

export {commentRouter};
