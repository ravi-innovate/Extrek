import express from 'express';
import {Post} from '../models.js';
const postRouter = express.Router();


postRouter.post('/',async(req,res)=>{
	let {post_title, post_content, post_location, writer_id, status} = req.body;
	console.log(req.body);
	const post = new Post({post_title, post_content, post_location, writer_id, status})
	await post.save();
    res.json({'status':200});
});

postRouter.patch('/update/:fieldName',async(req,res)=>{
	let fieldName = req.params.fieldName;
	let newValue = req.body[fieldName];
	let Id = req.body.Id;
	console.log(req.body);
	//const writer = new Writer();
	try 
	{
		const updateStatus = await  Post.findOneAndUpdate({_id : Id},{[fieldName]:newValue});
		if (updateStatus) {
			console.log('Post updated successfully:', updateStatus);
			res.status(200).json({'status':"success"});
		} else {
			console.log('Post not found');
			res.status(404).json({'status':404});
		}
	} catch (error) {
        console.error('Error updating Post:', error);
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
});

postRouter.get('/allPosts', async(req,res)=>{
	console.log(req.body);
	try 
	{
		const result = await  Post.find();
		if (result) {
			console.log('Posts fetched successfully:');
			res.status(200).json(result);
		} else {
			console.log('Post not found');
			res.status(404).json({'status':404});
		}
	} catch (error) {
        console.error('Error fetching Post:', error);
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
});

postRouter.get('/getOnesPost', async(req,res)=>{
	console.log(req.body);
	let Id = req.body.Id;
	try 
	{
		const result = await  Post.find({writer_id:Id,status: "saved"});
		if (result) {
			console.log('Posts fetched successfully:');
			res.status(200).json(result);
		} else {
			console.log('Post not found');
			res.status(404).json({'status':404});
		}
	} catch (error) {
        console.error('Error updating Post:', error);
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
});

postRouter.get('/getPost', async(req,res)=>{
	console.log(req.body);
	let Id = req.body.Id;
	try 
	{
		const result = await  Post.findOne({writer_id:Id, status: "saved"});
		if (result) {
			console.log('Post fetched successfully:');
			res.status(200).json(result);
		} else {
			console.log('Post not found');
			res.status(404).json({'status':404});
		}
	} catch (error) {
        console.error('Error updating Post:', error);
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
});
export {postRouter};