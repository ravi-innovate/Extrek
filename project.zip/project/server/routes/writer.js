import express from 'express';
import {Writer} from '../models.js';
import multer from 'multer';

const writerRouter = express.Router();


const storage = multer.memoryStorage();
const upload = multer({ storage });

 function writerRout(gfs)
 {
	writerRouter.post('/',async(req,res)=>{
		let {writer_username, writer_name, writer_email, writer_phone, writer_password, writer_bio, writer_gender} = req.body;
		console.log(req.body);
		const writer = new Writer({writer_username, writer_name, writer_email, writer_phone, writer_password, writer_bio, writer_gender})
		await writer.save();
		res.json({'status':200});
	});

	writerRouter.post('/pic', upload.single('image'), (req, res) => {
		const { file } = req;
	
		// Check if file exists
		if (!file) {
		return res.status(400).json({ message: 'No file uploaded' });
		}
	
		// Create write stream
		const writeStream = gfs.createWriteStream({ filename: file.originalname });
		writeStream.end(file.buffer);
	
		writeStream.on('finish', () => {
		res.status(200).json({ message: 'File uploaded successfully' });
		});
	
		writeStream.on('error', (err) => {
		console.error('Error uploading file:', err);
		res.status(500).json({ error: 'Internal server error' });
		});
	});

	writerRouter.patch('/update/:fieldName',async(req,res)=>{
		let fieldName = req.params.fieldName;
		let newValue = req.body[fieldName];
		let Id = req.body.Id;
		console.log(req.body);
		//const writer = new Writer();
		try 
		{
			const updateStatus = await  Writer.findOneAndUpdate({_id : Id},{[fieldName]:newValue});
			if (updateStatus) {
				console.log('User updated successfully:', updateStatus);
				res.status(200).json({'status':"success"});
			} else {
				console.log('User not found');
				res.status(404).json({'status':404});
			}
		} catch (error) {
			console.error('Error updating user:', error);
			res.status(500).json({ status: 'error', message: 'Internal server error' });
		}
	});

	writerRouter.get('/allWriters', async(req,res)=>{
		console.log(req.body);
		try 
		{
			const result = await  Writer.find();
			if (result) {
				console.log('Writers fetched successfully:');
				res.status(200).json(result);
			} else {
				console.log('User not found');
				res.status(404).json({'status':404});
			}
		} catch (error) {
			console.error('Error updating user:', error);
			res.status(500).json({ status: 'error', message: 'Internal server error' });
		}
	});

	writerRouter.get('/getWriter/:Id', async(req,res)=>{
		let Id = req.params.Id;
		try 
		{
			const result = await  Writer.findOne({_id:Id});
			if (result) {
				console.log('Writer fetched successfully:');
				res.status(200).json(result);
			} else {
				console.log('User not found');
				res.status(404).json({'status':404});
			}
		} catch (error) {
			console.error('Error updating user:', error);
			res.status(500).json({ status: 'error', message: 'Internal server error' });
		}
	});

	
	return writerRouter;
}

export {writerRout};