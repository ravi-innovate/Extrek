import express from 'express';
import {Notify} from '../models.js';
const notifyRouter = express.Router();

notifyRouter.post('/',async(req,res)=>{
	let {writer_id, content, date, status} = req.body;
	console.log(req.body);
	const notify = new Notify({writer_id, content, date, status})
	await notify.save();
    res.json({'status':200});
});

export {notifyRouter};