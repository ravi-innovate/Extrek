import express from 'express';
import {Like} from '../models.js';
const likeRouter = express.Router();

likeRouter.post('/add',async(req,res)=>{
	let {post_id} = req.body;
	let writer_id = req.userId;
	const like = new Like({"post_id":post_id,"writer_id": writer_id})
	await like.save();
    res.json({'status':200});
});
likeRouter.delete('/remove', async (req, res) => {
    try {
        let { post_id } = req.query;
        let writer_id = req.userId;
        
        console.log({"post_id": post_id,"writer_id": writer_id});
        
        const result = await Like.findOneAndDelete({"post_id": post_id, "writer_id": writer_id});
        
        if (result) {
            res.json({'status': 200, 'message': 'Like removed successfully'});
        } else {
            res.status(404).json({'status': 404, 'message': 'Like not found'});
        }
    } catch (error) {
        console.error("Error deleting like:", error);
        res.status(500).json({'status': 500, 'message': 'Internal Server Error'});
    }
});

likeRouter.get('/', async (req, res) => {
    try {
        const { post_id } = req.query;
        const writer_id = req.userId;

        const like = await Like.findOne({ post_id, writer_id });

        if (like) {
            res.json({ liked: true });
        } else {
            res.json({ liked: false });
        }
    } catch (error) {
        console.error("Error fetching like status:", error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

export {likeRouter};