import mongoose from 'mongoose';
const writerSchema = new mongoose.Schema({
    writer_username : {type:String,unique:true},
    writer_name : String,
    writer_email : String,
    writer_phone : String,
    writer_password : String,
    writer_bio : String,
    writer_gender : {type : String, enum: ["Male","Female","Other"], default: 'Male'},
})

const postSchema = new mongoose.Schema({
    post_title : String,
    post_content : String,
    post_date :{
        type: Date,
        default: Date.now
    },
    post_location : String,
    writer_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Writer'
    },
    status : {
        type:String,
        enum : ["saved","draft","deleted"],
        default :"saved"
    }
})

const followSchema = new mongoose.Schema({
    update :{
        type: Date,
        default: Date.now
    },
    who: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Writer'
    },
    to: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Writer'
    },
    return: {
        type:Boolean,
        default:false
    },
})

const likeSchema = new mongoose.Schema({
    post_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Post',
        required : true

    },
    writer_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Writer',
        required : true

    }
})

const commentSchema = new mongoose.Schema({
    post_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Post'
    },
    writer_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Writer'
    },
    content: {type: String, require: true},
    status:{
        type: String,
        enum : ["enabled", "hide", "updated"],
        default : "enabled"
    },
    like: {
        type : Number,
        default : 0
    }
})

const notifySchema = new mongoose.Schema({
    writer_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Writer'
    },
    content: {type: String, require: true},
    date :{
        type: Date,
        default: Date.now
    },
    status:{
        type: String,
        enum : ["sending", "sended", "failed", "read"]
    }
})
		
const Writer = mongoose.model('writers',writerSchema);
const Post = mongoose.model('posts',postSchema);
const Like = mongoose.model('likes',likeSchema);
const Comment = mongoose.model('comments',commentSchema);
const Follow = mongoose.model('follows',followSchema);
const Notify = mongoose.model('notifies',notifySchema);
	
export {Writer, Post, Like, Comment, Follow, Notify};