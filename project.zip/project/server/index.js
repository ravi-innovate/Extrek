import express from 'express';
import cors from 'cors';
import {Writer} from './models.js'
import mongoose from 'mongoose';
import Grid from 'gridfs-stream';
import jwt from 'jsonwebtoken';
const app = express();

app.use(cors());
app.use(express.json());


const generateToken = (user) => {
    const token = jwt.sign({ id: user.toString() }, 'my@key', { expiresIn: '1h' });
    return token;
};

const verifyToken = (req, res, next) => {
    const token = req.headers.authorization; //send header (abhi baki hain)
    if (!token) {
        return res.status(401).json({ message: 'No token provided'});
    }

    jwt.verify(token, 'my@key', (err, decoded) => {
        if (err) {
            return res.status(403).json({ message: 'Failed to authenticate token' });
        }

        req.userId = decoded.id;
		console.log("_____________________________________________________________________________________________________________________________",req.userId)

        next();
    });
};

mongoose.connect('mongodb://127.0.0.1:27017/aurora');
const conn = mongoose.connection;
let gfs;
conn.once('open', () => {
  gfs = Grid(conn.db, mongoose.mongo);
  gfs.collection('uploads');
});

import {postRouter} from  './routes/post.js';
import {writerRout} from './routes/writer.js';
import {likeRouter} from  './routes/like.js';
import {commentRouter} from  './routes/comment.js';
import {notifyRouter} from  './routes/notify.js';



app.get('/writer/Login', async(req,res)=>{
	let body = req.query;
	//console.log(body)
	try 
	{
		const result = await  Writer.findOne(body);
		if (result) {
			console.log('login success');
			const token = generateToken(result._id)
			res.json({token:token});
		} else {
			console.log('User not found');
			res.json({});
		}
	} catch (error) {
		console.error('internal issue..!', error);
		res.status(500).json({ status: 'error', message: 'Internal server error' });
	}
});

app.get('/writer/username/:Id', async(req,res)=>{
	let Id = req.params.Id;
	try 
	{
		const result = await  Writer.findOne({_id:Id},{_id:0,writer_username:1});
		if (result) {
			console.log('Writer fetched successfully:');
			res.status(200).json(result);
		} else {
			console.log('User not found');
			res.status(404).json({'status':404});
		}
	} catch (error) {
		console.error('Error updating user:', error);
		res.status(500).json({ status: 'error', message: 'Internal server error' });
	}
});

app.use('/post',postRouter);
app.use(verifyToken);
app.use('/like',likeRouter);
app.use('/writer',writerRout(gfs));
app.use('/comment',commentRouter);
app.use('/notify',notifyRouter);


app.listen(9000,()=>{
    console.log("running");
});

/*
{
	"writer_user" : "t_ksrawat",
	"writer_name" : "KS Rawat",
	"writer_email" : "kartik@gmail.com",
	"writer_phone" : "894323940",
	"writer_password" : "pass1@",
	"writer_bio" : "I am a rider",
	"writer_gender" : "Male"
}


	{
		"post_title" : "Thar's Car",
		"post_content" :"This is a hot place to convert your cold blood to boiled. it's morning and evening is ummha....!",
		"post_location" : "jhodhpur, Rajasthan",
		"writer_id":"6635c2c3f7f09336fe126cf7" 
	}

	{
  "writer_id":"6635c39c01a4db0d86596805",
  "content":"Sudhanshu90 Like your post",
  "status": "sended"
}
*/