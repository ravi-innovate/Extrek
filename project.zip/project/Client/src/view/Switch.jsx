import { useContext } from "react";
import { getToken, deleteToken } from "../TOKEN_HANDLER.js";
import { LoginRender } from '../App.jsx';
export default function Switch(){
    let username="Sign in";
    const {Render, setRender} = useContext(LoginRender);
    const showLoginForm = () => {
        setRender((Render)=> ({"status":!Render.status}));
    }
    // deleteToken()
    if(getToken()){
        username = Render.username;
    }
    return(
        <>
            <div style={{"display":"flex","width":"fit-content"}}>
                <font size="4" style={{"Width":"100px",padding:"0px 15px",border:"2px solid #017362",borderRadius:"20px",cursor:"pointer",fontWeight:"bold"}} onClick={showLoginForm}> { username } </font> 
            </div>
        </>
    );
}

