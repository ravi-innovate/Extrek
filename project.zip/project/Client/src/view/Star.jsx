export default function Star(){
    return (
        <>
            <span style={{fontSize:"32px",color:"#fff1a"}}> &#9734; </span>
        </>
    )
}