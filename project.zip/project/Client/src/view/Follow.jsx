import { FiUserPlus } from "react-icons/fi";
export default function Comment(){
    return (
        <>
            <FiUserPlus style={{fontSize:"22px",color:"#fff1a",margin:"10px"}}/>
        </>
    )
}