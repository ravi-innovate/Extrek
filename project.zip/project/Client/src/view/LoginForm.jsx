import Input from './Input.jsx';
import Css from '../Styles/LoginForm.module.css';
import Button from './Button.jsx';
import {useState, useContext, createContext} from 'react';
import {setToken} from '../TOKEN_HANDLER.js'
import axios from 'axios';
import {LoginRender} from '../App.jsx';
//const LoginStatus = createContext();

export default function LoginForm(){
    const [LoginStatus, setLoginStatus]= useState();
    const [LoginData,setLoginData] = useState({});
    let [status,setStatus]=useState();
    const {setRender} = useContext(LoginRender);
    const showLoginForm = () => {
        setRender((Render)=> ({status:!Render.status}));
    }
    const login = () => {
        console.log(LoginData);
        axios.get('http://localhost:9000/writer/Login',{params:LoginData}).then((response) => {
                if(Object.keys(response.data).length !== 0){
                    setToken(response.data.token);
                    showLoginForm();
                    setRender((Render)=> ({...Render,"username":LoginData.writer_username}));
                    console.log("hello Dost:- ",response.data.token);
                }
                else{
                    setStatus("username or password is wrong!")
                }
            })
            .catch((error) => {
                console.log("internal server issues....!",);
            });  
    }
   // console.log(LoginData);
    return (
        <div className={Css.LoginForm}>
            <h1 align="center"> Welcome to ExTrek! <br /> Sign in </h1>
            <Input hint="Username" name="writer_username"  type="text" get={setLoginData}/>
            <Input hint="Password" name="writer_password"  type="password" get={setLoginData}/>
            <font size="2" style={{minWidth:"85%",textAlign: "left",textDecoration:"underline"}} > Forget Password? </font>
            <font size="2" style={{textDecoration:"underline",textAlign: "left",minWidth:"85%"}} > Don't have an account? Create new. </font>
            <Button event={login} name=" Sign In "/>
            <font size="2" style={{color:"red"}} > {status} </font>
        </div>
    )
}