import Css from "../Styles/Dp.module.css";

export default function Dp(){
    return <>
        <img src="../src/assets/Dp.png" className={Css.Dp} alt="DP" />
        
    </>
}