import { FaRegComment } from "react-icons/fa";
export default function Comment(){
    return (
        <>
            <FaRegComment style={{fontSize:"22px",color:"#fff1a",margin:"10px"}}/>
        </>
    )
}