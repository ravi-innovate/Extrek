export default function Logo(){
    return (
        <>
           <font size="6" style={{color:"#017362",fontFamily:"Colonna MT"}}> ExTrek </font> 
        </>
    );
}