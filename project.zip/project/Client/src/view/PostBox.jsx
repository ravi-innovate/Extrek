import Css from '../Styles/PostBox.module.css';
import Post from './Post.jsx';
import {useState, useEffect} from 'react'
import axios from 'axios';
import { getToken } from '../TOKEN_HANDLER.js';
export default function PostBox(){
    let [posts,setPosts]=useState([]);
    useEffect(()=>{
        axios.get('http://localhost:9000/post/allposts',{handers:{authorization:getToken()}})
        .then(res => setPosts(res.data))
        .catch(()=>{console.log("something is wrong..!")});
    },[])
   console.log(posts)
    return (
        <div className={Css.PostBox}>
            {
                posts.map((data,key)=>(
                    <Post key={key} data={data} style={{"maxWidth":"50%"}}></Post>
                ))
            }
        </div>
    )
}