import React, { useState } from 'react';
import axios from 'axios';
import Dropzone from 'react-dropzone';

const ImageUpload = () => {
  const [file, setFile] = useState(null);

  const onDrop = (acceptedFiles) => {
    setFile(acceptedFiles[0]);
  };

  const onSubmit = async() => {
    const formData = new FormData();
    formData.append('image', file);

    try {
      await axios.post('http://localhost:9000/writer/pic', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      alert('Image uploaded successfully!');
    } catch (error) {
      console.error('Error uploading image:', error);
    }
  };

  return (
    <div>
      <h2>Upload Image</h2>
      <Dropzone onDrop={onDrop} accept="image/*">
        {({ getRootProps, getInputProps }) => (
          <div {...getRootProps()} style={{ border: '2px dashed #ccc', padding: '20px', textAlign: 'center' }}>
            <input {...getInputProps()} />
            <p>Drag and drop an image here, or click to select an image</p>
          </div>
        )}
      </Dropzone>
      {file && (
        <div>
          <h3>Selected Image:</h3>
          <img src={URL.createObjectURL(file)} alt="Selected" style={{ maxWidth: '100%' }} />
          <button onClick={onSubmit}>Upload Image</button>
        </div>
      )}
    </div>
  );
};

export default ImageUpload;
