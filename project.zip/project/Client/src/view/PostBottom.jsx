import Css from '../Styles/PostHead.module.css';
import Like from './Like.jsx';
import Follow from './Follow.jsx';
import Comment from './Comment.jsx';
export default function PostBottom({date,location, id}){
    return (
        <div className={Css.PostHead}>
            <div style={{fontSize:"0.8em",padding:"8px",flexGrow:1}}>
                {date}  <br/>   {location}
            </div>
            <Follow/>
            <Comment/>
            <Like id={id}/>
        </div>
    )
}