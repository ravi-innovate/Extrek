import Dp from './Dp.jsx';
import Star from './Star.jsx';
import Css from '../Styles/PostHead.module.css';
import {useState, useEffect} from 'react';
import axios from 'axios';
export default function PostHead({title,writer}){
    
    console.log(writer);
    return (
        <div className={Css.PostHead}>
            <Dp></Dp>
            <div style={{lineHeight:"16px",padding:"8px",flexGrow:1}}>
                <font size="4"> {title}</font> <br/>
                <font style={{fontSize:"0.69em"}}>{writer}</font>
            </div>
            <Star/>
        </div>
    )
}