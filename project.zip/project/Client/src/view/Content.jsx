import Css from '../Styles/Content.module.css';
export default function Content({blog}){
    return(
        <div className={Css.Content}>
            {blog}
        </div>
    );
}