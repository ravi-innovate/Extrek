import Button from './Button.jsx';
import Css from "../Styles/Header.module.css";

export default function Header(){

        return (
            <div className={Css.Header}>
                <Button name="Popular"></Button>
                <Button name="Recent"></Button>
                <Button name="For You"></Button>
                <Button name="Favorite"></Button>
            </div>
        );
}