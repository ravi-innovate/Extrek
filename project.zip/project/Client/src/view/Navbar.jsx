import Logo from "./Logo.jsx";
import Switch from "./Switch.jsx";
import Header from './Header.jsx';

import Css from "../Styles/Navbar.module.css";
function Navbar(){
    return (
        <>
            <div className={Css.Navbar}>
                <Logo></Logo>
                <Header></Header>
                <Switch></Switch>
            </div>
        </>
    );
}

export default Navbar;