import { FaHeart } from "react-icons/fa6";
import { getToken } from "../TOKEN_HANDLER";
import { useEffect, useState } from "react";
import axios from 'axios';

export default function Like({ id }) {
    const [likeData, setLikeData] = useState({ color: "#ff6666", api: "remove" });

    useEffect(() => {
        const fetchLikeStatus = async () => {
            try {
                const response = await axios.get(`http://localhost:9000/like/`, {
                    params: { post_id: id },
                    headers: { "authorization": getToken() }
                });

                const liked = response.data.liked;
                console.log("Fetch like status:", liked);
                if (liked) {
                    setLikeData({ color: "#ff6666", api: "remove" });
                } else {
                    setLikeData({ color: "#fff", api: "add" });
                }
            } catch (e) {
                console.log("something is wrong..!", e);
            }
        };
        
        // fetchLikeStatus();
    }, [id]);

    const like = async () => {
        try {
            if (likeData.api === "add") {
                await axios.post(`http://localhost:9000/like/add`, { post_id: id }, {
                    headers: { "authorization": getToken() }
                });
                console.log("liked");
                setLikeData({ color: "#ff6666", api: "remove" });
            } else {
                await axios.delete(`http://localhost:9000/like/remove`, {
                    params: { post_id: id },
                    headers: { "authorization": getToken() }
                });
                console.log("disliked");
                setLikeData({ color: "#fff", api: "add" });
            }
        } catch (e) {
            console.log("something is wrong..!", e);
        }
    };

    
        console.log("LikeData changed:", likeData.color);
    

    return (
        <>
         
        <FaHeart
            style={{ fontSize: "22px", margin: "10px", color: likeData.color }}
            onClick={like}
            />
        </>

    );
}
