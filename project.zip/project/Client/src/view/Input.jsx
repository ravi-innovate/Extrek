import Css from '../Styles/Input.module.css';
export default function Input(props){
    const getValue = (e) =>{
        props.get(value =>(
            {...value,[e.target.name]:e.target.value}
        ))
        
    }
    return(
        <>
            <input type={props.type} name={props.name} value={props.value} placeholder={props.hint} onChange={getValue} className={Css.Input} />
        </>
    )
}