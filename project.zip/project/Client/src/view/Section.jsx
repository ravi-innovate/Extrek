import Css from '../Styles/Section.module.css';
import PostBox from './PostBox.jsx';
import LoginForm from './LoginForm.jsx';
import { useContext } from 'react';
import { LoginRender } from '../App.jsx';
export default function Section({bool}){
    const {Render} = useContext(LoginRender);
    return (
    <div className={Css.Section}>
        <PostBox></PostBox>
        {Render.status && <LoginForm/> }
    </div>
    );
}