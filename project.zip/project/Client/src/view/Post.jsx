import PostHead from './PostHead.jsx';
import Content from './Content.jsx';
import PostBottom from './PostBottom.jsx';
import Css from '../Styles/Post.module.css';
import {getToken} from '../TOKEN_HANDLER.js'
import {useState, useEffect} from 'react';
import axios from 'axios';
export default function Post({data}){
    let [writer,setWriter]=useState([]);
    useEffect(()=>{
        axios.get('http://localhost:9000/writer/username/'+data.writer_id)
        .then(res => {setWriter(res.data),console.log("data",res.data)})
        .catch((e)=>{console.log("something is wrong..!",e)});
    },[])
    function likeIn(){
        
    }
    return (
        <div className={Css.Post}>
            <PostHead title={data.post_title} writer={writer.writer_username}></PostHead>
            <Content blog={data.post_content}></Content>
            <PostBottom date={data.post_date} id={data._id} location={data.post_location}></PostBottom>
        </div>
    )
}