import Css from "../Styles/Button.module.css";

export default function Button(Values){
    console.log(Values)
    return <button onClick={Values.event} className={Css.Button}> {Values.name} </button>
} 