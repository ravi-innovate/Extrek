import { useState, createContext } from 'react';
import Navbar from './view/Navbar.jsx';
import Section from './view/Section.jsx';
import './App.css';

const LoginRender = createContext()
function App() {
  const [Render,setRender]= useState({status:false});
  console.log("login:",Render)
  return (
    <LoginRender.Provider value={{Render,setRender}}>
      <Navbar></Navbar>
      <Section></Section>
    </LoginRender.Provider>
  )
}

export default App
export { LoginRender };